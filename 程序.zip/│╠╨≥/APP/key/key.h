#ifndef _key_H
#define _key_H


#include "system.h"
 

void KEY_Init(void);


#endif
