/*
 * @Author: error: error: git config user.name & please set dead value or install git && error: git config user.email & please set dead value or install git & please set dead value or install git
 * @Date: 2024-04-06 16:55:03
 * @LastEditors: error: error: git config user.name & please set dead value or install git && error: git config user.email & please set dead value or install git & please set dead value or install git
 * @LastEditTime: 2024-04-11 14:53:55
 * @FilePath: \����\APP\led\led.h
 * @Description: ����Ĭ������,������`customMade`, ��koroFileHeader�鿴���� ��������: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
#ifndef _led_H
#define _led_H

#include "system.h"

/*  LEDʱ�Ӷ˿ڡ����Ŷ��� */
#define LED1_PORT GPIOA
#define LED1_PIN GPIO_Pin_4
#define LED1_PORT_RCC RCC_APB2Periph_GPIOA

#define LED2_PORT GPIOA
#define LED2_PIN GPIO_Pin_7
#define LED2_PORT_RCC RCC_APB2Periph_GPIOA

#define BEEP_PORT GPIOB
#define BEEP_PIN GPIO_Pin_5
#define BEEP_PORT_RCC RCC_APB2Periph_GPIOB

#define LED1 PAout(4)
#define LED2 PAout(7)
#define BEEP PBout(5)

void LED_Init(void);

#endif
